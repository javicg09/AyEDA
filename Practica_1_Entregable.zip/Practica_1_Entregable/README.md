# Modificación:

Siempre que la hormiga esté orientada hacia arriba y gire a la derecha, aumentar un contador y ver al fnal cuantas veces se hizo